#!/bin/sh
if [ -n $1 ]
then
INSTALLDIR=/opt/Canon
else
INSTALLDIR=$1
fi
SANECONFDIR=/etc/sane.d
SCANNERNAME=dr-m260
MODELCONF=$SCANNERNAME.conf


if [ -e $INSTALLDIR/etc/sane.d/canondr/$MODELCONF ]
then
	rm -f $INSTALLDIR/etc/sane.d/canondr/$MODELCONF
fi

if [ -e $INSTALLDIR/etc/sane.d/canondr.conf ]
then
	cat $INSTALLDIR/etc/sane.d/canondr.conf|awk '$3=="dr-m260"{print NR}'>tmp.txt
	read  START < tmp.txt
	if [ $? -eq 0 ]
	then
		cat $INSTALLDIR/etc/sane.d/canondr.conf|sed "$START, +4 d" > out.txt
		cp -f out.txt $INSTALLDIR/etc/sane.d/canondr.conf
		rm -f tmp.txt out.txt
	fi
fi

LINE=`cat $INSTALLDIR/etc/sane.d/canondr.conf|wc -l`
if [ $LINE -lt 4 ]
then
	rm -f $INSTALLDIR/etc/sane.d/canondr.conf
	rm -f $SANECONFDIR/canondr.conf
	
	CONFFILE=$SANECONFDIR/dll.conf
   if [ -n "`grep ^canondr $CONFFILE`" ];then
		sed -i 's/^canondr/#canondr/' $CONFFILE
   fi

fi

