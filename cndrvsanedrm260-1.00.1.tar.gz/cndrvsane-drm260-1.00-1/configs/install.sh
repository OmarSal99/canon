#!/bin/sh
if [ -n $1 ]
then
INSTALLDIR=/opt/Canon
else
INSTALLDIR=$1
fi
SANECONFDIR=/etc/sane.d
SCANNERNAME=dr-m260
MODELCONF=$SCANNERNAME.conf


if [ -e $INSTALLDIR/etc/sane.d/canondr/$MODELCONF ]
then
	rm -f $INSTALLDIR/etc/sane.d/canondr/$MODELCONF
fi


cp -f ./$MODELCONF $INSTALLDIR/etc/sane.d/canondr/$MODELCONF


if [ -e $INSTALLDIR/etc/sane.d/canondr.conf ]
then
	(if grep -q "dr-m260" $INSTALLDIR/etc/sane.d/canondr.conf;then :;  \
	else cat canondr.conf >> $INSTALLDIR/etc/sane.d/canondr.conf; fi)
else
	cp -f ./canondr.conf $INSTALLDIR/etc/sane.d/canondr.conf
	ln -sf $INSTALLDIR/etc/sane.d/canondr.conf $SANECONFDIR/
	
	CONFILE=$SANECONFDIR/dll.conf
	if [ -n "`grep '#[[:space:]]*canondr' $CONFILE`" ];then
  	sed -i 's,#[[:space:]]*\(canondr\),\1,' $CONFILE
	elif [ -z "`grep canondr $CONFILE`" ];then
   	echo canondr >> $CONFILE
	fi
	
fi

