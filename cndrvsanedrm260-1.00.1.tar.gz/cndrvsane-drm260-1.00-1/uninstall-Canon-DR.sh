#!/bin/sh
INSTALLDIR=/opt/Canon
DOCDIR=/usr/share/doc/cndrvsane-drm260

cd bin
if [ -e ./uninstall.sh ]
then
	chmod 755 ./uninstall.sh
	./uninstall.sh $INSTALLDIR
else
	echo "bin/uninstall.sh is not exist!"
	exit 1
fi
cd ..

cd configs
if [ -e ./uninstall.sh ]
then
	chmod 755 ./uninstall.sh
	./uninstall.sh $INSTALLDIR
else
	echo "configs/uninstall.sh is not exist!"
	exit 1
fi
cd ..

cd src
if [ -e ./uninstall.sh ]
then
	chmod 755 ./uninstall.sh
	./uninstall.sh $INSTALLDIR
else
	echo "src/uninstall.sh is not exist!"
	exit 1
fi
cd ..

rm -rf $DOCDIR

if [ ! -e /opt/Canon/etc/sane.d/canondr.conf ]
then
	rm -rf $INSTALLDIR
fi

