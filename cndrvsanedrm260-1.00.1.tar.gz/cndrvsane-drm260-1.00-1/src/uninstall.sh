#!/bin/sh
if [ -n $1 ]
then
INSTALLDIR=/opt/Canon
else
INSTALLDIR=$1
fi
SANECONFDIR=/etc/sane.d
SANELIBDIR=/usr/lib64/sane

if [ ! -e $SANECONFDIR/canondr.conf ]
then
	if [ -e $INSTALLDIR/lib/canondr/canondr_com_usb* ]
	then
		rm -f $INSTALLDIR/lib/canondr/canondr_com_usb*
	fi

	if [ -e $INSTALLDIR/lib/sane/libsane-canondr.so.1.0.1 ]
	then
		rm -f $INSTALLDIR/lib/sane/libsane-canondr.so.1.0.1
		rm -f $SANELIBDIR/libsane-canondr.so
		rm -f $SANELIBDIR/libsane-canondr.so.1
		rm -f $SANELIBDIR/libsane-canondr.so.1.0.0
	fi
fi

