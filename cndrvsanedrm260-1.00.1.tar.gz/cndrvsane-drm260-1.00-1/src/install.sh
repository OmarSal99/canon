#!/bin/sh
if [ -n $1 ]
then
INSTALLDIR=/opt/Canon
else
INSTALLDIR=$1
fi
SANELIBDIR=/usr/lib64/sane

if [ -e $INSTALLDIR/lib/canondr/canondr_com_usb.1.1.0 ]
then
	rm -f $INSTALLDIR/lib/canondr/canondr_com_usb.1.1.0
fi
cp -f ./canondr_com_usb $INSTALLDIR/lib/canondr/canondr_com_usb.1.1.0
chmod 4755 $INSTALLDIR/lib/canondr/canondr_com_usb.1.1.0

if [ -e $INSTALLDIR/lib/sane/libsane-canondr.so.1.0.1 ]
then
	rm -f $INSTALLDIR/lib/sane/libsane-canondr.so.1.0.1
	cp -f ./.libs/libsane-canondr.so.1.0.1 $INSTALLDIR/lib/sane/libsane-canondr.so.1.0.1
else
	cp -f ./.libs/libsane-canondr.so.1.0.1 $INSTALLDIR/lib/sane/libsane-canondr.so.1.0.1
	ln -sf $INSTALLDIR/lib/sane/libsane-canondr.so.1.0.1 $SANELIBDIR/libsane-canondr.so.1.0.0
	ln -sf $INSTALLDIR/lib/sane/libsane-canondr.so.1.0.1 $SANELIBDIR/libsane-canondr.so.1
	ln -sf $INSTALLDIR/lib/sane/libsane-canondr.so.1.0.1 $SANELIBDIR/libsane-canondr.so
fi


