/*  Canon Electronics Scanner Driver for Linux Version 1.00
 *  Copyright CANON ELECTRONICS INC. 2009
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include <sys/time.h>
#include "sane/sane.h"
#include "sane/sanei_usb.h"
#include "sane/sanei_config.h"
#include "Canon_DR.h"

/* for test */
#ifdef BTEST
int branchTest(int x);
void clearBranch(void);
#define BRANCH_TEST(x) branchTest(x)
#define CLEAR_BRANCH() clearBranch()
#else
#define BRANCH_TEST(x) 0
#define CLEAR_BRANCH() 
#endif


static int usbFd = -1;
static char *deviceName;

static void doRead(char *buf, unsigned int size)
{
    int r;
    char *p;

    p = buf;
    while (size > 0) {
        if (BRANCH_TEST(1) || BRANCH_TEST(2)) {
            r = -1;
        } else {
            r = read(0,p,size);
        }
        if (r <= 0) {
            if ((r < 0 && (errno == EAGAIN || errno == EINTR))
                || BRANCH_TEST(2)) {
                CLEAR_BRANCH();
                continue;
            }
            exit(2);
        }
        p += r;
        size -= r;
    }
}

static void doWrite(const char *buf, unsigned int size)
{
    int r;
    const char *p;

    p = buf;
    while (size > 0) {
        if (BRANCH_TEST(3) || BRANCH_TEST(4)) {
            r = -1;
        } else {
            r = write(1,p,size);
        }
        if (r <= 0) {
            if (((r < 0) && (errno == EAGAIN || errno == EINTR))
                 || BRANCH_TEST(4)) {
                CLEAR_BRANCH();
                continue;
            }
            exit(2);
        }
        p += r;
        size -= r;
    }
}

static void readWord(SANE_Word *word)
{
    char buf[4];
    SANE_Word x;
    int i;

    doRead(buf,4);
    x = 0;
    for (i = 0;i < 4;i++) {
        x = (x << 8) | (buf[i] & 0xff);
    }
    *word = x;
}

static void writeWord(SANE_Word word)
{
    char buf[4];
    int i;

    for (i = 0;i < 4;i++) {
        buf[3-i] = (word & 0xff);
        word >>= 8;
    }
    doWrite(buf,4);
}

static void usbRead(void)
{
    SANE_Status status = SANE_STATUS_GOOD;
    SANE_Word n;
    static unsigned char *buf = NULL;
    static unsigned int bufSize = 0;

    readWord(&n);
    if (bufSize < n) {
        if ((buf = realloc(buf,n)) == NULL || BRANCH_TEST(5)) {
            writeWord(SANE_STATUS_NO_MEM);
            writeWord(0); /* read data size */
            bufSize = 0;
            return;
        }
        bufSize = n;
    }
    if (usbFd < 0) {
        status = sanei_usb_open(deviceName,&usbFd);
    }
    if (status == SANE_STATUS_GOOD) {
	 size_t st = n;
        status = sanei_usb_read_bulk(usbFd,buf,(size_t *)&st);
	 n=st;
    }
    writeWord(status);
    if (status != SANE_STATUS_GOOD) n = 0;
    writeWord(n);
    doWrite((char *)buf,n);
}

static void usbWrite(void)
{
    SANE_Status status = SANE_STATUS_GOOD;
    SANE_Word n;
    static unsigned char *buf = NULL;
    static unsigned int bufSize = 0;

    readWord(&n);
    if (bufSize < n) {
        if ((buf = realloc(buf,n)) == NULL || BRANCH_TEST(6)) {
            char tbuf[256];

            bufSize = 0;
            /* read data */
            while (n > 0) {
                int r = n > sizeof(tbuf) ? sizeof(tbuf) : n;

                doRead((char *)tbuf,r);
                n -= r;
            }
            writeWord(SANE_STATUS_NO_MEM);
            return;
        }
    }
    doRead((char *)buf,n);
    if (usbFd < 0) {
        status = sanei_usb_open(deviceName,&usbFd);
    }
    if (status == SANE_STATUS_GOOD) {
	 size_t st = n;
        status = sanei_usb_write_bulk(usbFd,buf,(size_t *)&st);
    }
    writeWord(status);
}

static void usbClear(void)
{
    SANE_Status status;
    sanei_usb_close(usbFd);
    status = sanei_usb_open(deviceName,&usbFd);
    writeWord(status);
}


static void usbClear2(void)
{
    sanei_usb_clear_halt(usbFd);
    writeWord(SANE_STATUS_GOOD);
}


static void usbControlRead(void)
{
	SANE_Status status = SANE_STATUS_GOOD;
	SANE_Word n;
	static unsigned char *buf = NULL;
	static unsigned int bufSize = 0;

	SANE_Word rtype;
	SANE_Word req;
	SANE_Word value;
	SANE_Word index;	
	/* read request type */
	readWord(&rtype);
	/* read actual request */
	readWord(&req);
	/* read parameter specific to the request*/
	readWord(&value);		
	/* read index */
	readWord(&index);
	/* read data packet length */
	readWord(&n);
	
	if (bufSize < n) {
		if ((buf = realloc(buf,n)) == NULL || BRANCH_TEST(5)) {
			writeWord(SANE_STATUS_NO_MEM);
			writeWord(0); /* read data size */
	    		bufSize = 0;
	    		return;
		}
    	}
    
	
	if (usbFd < 0) {
		status = sanei_usb_open(deviceName,&usbFd);
	}
	if (status == SANE_STATUS_GOOD) {
		status = sanei_usb_control_msg(usbFd, rtype,
					req,
					(SANE_Int)value,				 				index, 
					n, 
					(SANE_Byte*) buf);
	
	}
    
	writeWord(status);
	if (status != SANE_STATUS_GOOD) n = 0;
	writeWord(n);
	/* write data to the pipe */
	doWrite((char *)buf,n);
}
static void usbControlWrite(void)
{
	SANE_Status status = SANE_STATUS_GOOD;
    	SANE_Word n;
    	static unsigned char *buf = NULL;
    	static unsigned int bufSize = 0;
	SANE_Word rtype;
	SANE_Word req;
    	SANE_Word value;
	SANE_Word index;	
	/* read request type */
	readWord(&rtype);
	/* read actual request */
	readWord(&req);
	/* read parameter specific to the request*/
	readWord(&value);		
	/* read index */
	readWord(&index);
	/* read data packet length */
    	readWord(&n);
    	if (bufSize < n) {
		if ((buf = realloc(buf,n)) == NULL || BRANCH_TEST(6)) {
			char tbuf[256];
		
			bufSize = 0;
			/* read data */
			while (n > 0) {
				int r = n > sizeof(tbuf) ? sizeof(tbuf) : n;

				doRead((char *)tbuf,r);
				n -= r;
	   		}
			writeWord(SANE_STATUS_NO_MEM);
			return;
		}
    	}
   
	doRead((char *)buf,n);
	
	if (usbFd < 0) {
		status = sanei_usb_open(deviceName,&usbFd);
	}
	if (status == SANE_STATUS_GOOD) {
		status = sanei_usb_control_msg(usbFd, rtype, 
						value, 
						(SANE_Int) 
						value, 
						index, 
						n, 
						(SANE_Byte*) buf);
	}
	writeWord(status);
}
static void mainLoop(void)
{
    SANE_Word op;

    for (;;) {
        readWord(&op);
        switch (op) {
        case 1: /* READ */
            usbRead();
            break;
        case 2: /* WRITE */
            usbWrite();
            break;
        case 3: /* CLEAR */
            usbClear();
            break;
        case 4: /* Control Read with VendorUnique */
            usbControlRead();
            break;
        case 5: /* Control Write with VendorUnique */
            usbControlWrite();
            break;
	 case 6: /* CLEAR with usb_clear_halt()*/
	     usbClear2();
	     break;
        }
    }
}

static int deviceFound = 0;

static SANE_Status canon_attach(const char *dev)
{
    if (strcmp(deviceName, dev) == 0) {
        deviceFound = 1;
    }
    return SANE_STATUS_GOOD;
}

int main(int argc, char **argv)
{
    FILE *fp;
    char buf[4096];
    const char *p;

    if (argc < 2) {
        /* no device name, it's mandatory */
        fprintf(stderr,"Usage:%s <device name>\n",argv[0]);
        exit(2);
    }
    deviceName = argv[1];

    signal(SIGINT,SIG_IGN);

    sanei_usb_init();

    if (getuid() != geteuid() || BRANCH_TEST(7)) {
        /* For security reason,
          check if device is in config file.
          Because this program is set suid bit, check it
          or anybody can access arbitrary devices.
        */
        /* read config file */
        if ((fp = fopen(SANECONFDIR "/" CFG_FILE_NAME,"r")) == NULL) {
            return 2;
        }
        while (sanei_config_read(buf,sizeof(buf),fp) != NULL) {
            p = sanei_config_skip_whitespace(buf);
            if (*p == '\0') continue; /* empty line */
            if (*p == '#') continue; /* comment line */
            if (strncmp(p,"option",6) != 0) {
                /* device */
                sanei_usb_attach_matching_devices(p,canon_attach);
            }
        }
        fclose(fp);
        if (!deviceFound) {
            fprintf(stderr,"Specified device is not in config file\n");
            exit(2);
        }
    }

    sanei_usb_set_timeout(20000);
    if (!BRANCH_TEST(8)) mainLoop();
    return 0;
}
