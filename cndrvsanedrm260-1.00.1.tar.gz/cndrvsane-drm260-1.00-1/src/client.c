/*  Canon Electronics Scanner Driver for Linux Version 1.00
 *  Copyright CANON ELECTRONICS INC. 2009
 *  All Rights Reserved.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <limits.h>
#include <errno.h>
#include <sys/wait.h>
#include "sane/sane.h"
#include "sane/sanei.h"
#include "sane/sanei_net.h"
#include "sane/sanei_usb.h"
#include "sane/sanei_wire.h"
#include "sane/sanei_codec_bin.h"
#define BACKEND_NAME canondr
#define DEBUG_DECLARE_ONLY
#include "sane/sanei_backend.h"
#include "sane/sanei_config.h"
#include "Canon_DR.h"

/* for test */
#ifdef BTEST
int branchTest(int x);
void clearBranch(void);
#define BRANCH_TEST(x) branchTest(x)
#define CLEAR_BRANCH() clearBranch()
#else
#define BRANCH_TEST(x) 0
#define CLEAR_BRANCH() 
#endif

/* model, vendor, type, backendName */
#define MAX_OPT_STR_LEN 256

static SANE_Char model[MAX_OPT_STR_LEN];
static SANE_Char vendor[MAX_OPT_STR_LEN] = DEFAULT_VENDOR;
static SANE_Char type[MAX_OPT_STR_LEN];
static SANE_Char backendName[MAX_OPT_STR_LEN];
static long      scannerType;



/* device list */
#define MAX_DEVICES 100
/* the last element is kept NULL for end mark */
static SANE_Device *devices[MAX_DEVICES+1];
/* backend module name */
/* if NULL, default backend module is used */
static char *backendNames[MAX_DEVICES+1];
/* scanner_type name */
/* 0:feeder, 1:flatbed option */
static long scannerTypes[MAX_DEVICES+1];
/* backend module for FSU name */
/* if NULL, default backend module is used */
static char *modelForFSUs[MAX_DEVICES+1];



/* canon device structure */
typedef struct {
    char *name; /* if NULL, this is not open */
    int fd; /* socket fd for backend module */
    Wire wire;
    SANE_Handle backendHandle; /* backend side handle */
    SANE_Option_Descriptor_Array rawOptions; /* options loaded from backend */
    /* Because we should keep memory of options return to a frontend, 
       we keep copy of options */
    SANE_Option_Descriptor_Array options; /* copy of rawOptions */
    pid_t backendPID;
    pid_t comPID;
    int dataFd; /* fd of pipe for image data */
    unsigned int dataSize; /* remaing data size of image data packet */
} CanonDevice;

static CanonDevice openDevices[MAX_DEVICES];

static SANE_Status handle2Dev(SANE_Handle h, CanonDevice **dev)
{
    if ((int)h < 0 || (int)h >= MAX_DEVICES
      || openDevices[(int)h].name == NULL) {
        return SANE_STATUS_INVAL;
    }
    *dev = &(openDevices[(int)h]);
    if ((*dev)->fd < 0) {
        return SANE_STATUS_IO_ERROR;
    }
    return SANE_STATUS_GOOD;
}

static SANE_Status canon_attach(const char *dev)
{
    //fprintf(stderr, "dev is %s\r\n", dev);


    int i;

    for (i = 0;i < MAX_DEVICES && devices[i] != NULL;i++) {
        if (strcmp(devices[i]->name,dev) == 0) {
            return SANE_STATUS_GOOD;
        }
    }
    if (i >= MAX_DEVICES) {
        /* too many devices */
        return SANE_STATUS_INVAL;
    }
    devices[i] = (SANE_Device *)malloc(sizeof(SANE_Device));
    devices[i]->name   = strdup(dev);
    devices[i]->vendor = strdup(vendor);
    devices[i]->model  = strdup(model);
    devices[i]->type   = strdup(type);
    if (backendName[0] != '\0') {
        backendNames[i] = strdup(backendName);
    }

     /* for flatbed option */
    scannerTypes[i]=scannerType; 

     /* for flatbed option */

#if 0
fprintf(stderr, "devices[%d]->name is %s\r\n", i, devices[i]->name);
fprintf(stderr, "devices[%d]->vendor is %s\r\n", i, devices[i]->vendor);
fprintf(stderr, "devices[%d]->model is %s\r\n", i, devices[i]->model);
fprintf(stderr, "devices[%d]->type is %s\r\n", i, devices[i]->type);
fprintf(stderr, "backendNames[%d] is %s\r\n", i, backendNames[i]);
fprintf(stderr, "scannerTypes[%d] is %s\r\n", i, scannerTypes[i]==1?"flatbed option":"feeder");
fprintf(stderr, "modelForFSUs[%d] is %s\r\n", i, modelForFSUs[i]);
#endif

    return SANE_STATUS_GOOD;
}

static void freeDeviceList(void)
{
    int i;

    /* free devices */
    for (i = 0;i < MAX_DEVICES && devices[i] != NULL;i++) {
        free((void *)devices[i]->name);
        free((void *)devices[i]->vendor);
        free((void *)devices[i]->model);
        free((void *)devices[i]->type);
        free((void *)devices[i]);
        devices[i] = NULL;
        if (backendNames[i] != NULL) {
            free((void *)backendNames[i]);
            backendNames[i] = NULL;
        }
	/* for flatbed option */
	if (modelForFSUs[i] != NULL) {
	     free((void*)modelForFSUs[i]);
	     modelForFSUs[i] = NULL;
	}
        scannerTypes[i]=0;//feeder
	/* for flatbed option */
    }
}


int searchIndexOfFSU(int start_index)
{
   int idev=start_index;

    for (idev = start_index;idev < MAX_DEVICES && devices[idev] != NULL;idev++) {
        if (scannerTypes[idev]) {
	     /* index of flatbed scanner */
            return idev;
        }
    }
   return -1;
}


int searchIndexOfFeeder()
{
   int idev=0;

    for (idev = 0;idev < MAX_DEVICES && devices[idev] != NULL;idev++) {
        if (!scannerTypes[idev]) {
	     /* index of flatbed scanner */
            return idev;
        }
    }
    return -1;
}


void updateFSUDeviceList()
{

    int start_index = 0;

    int indexOfFSU = -1;
    int indexOfFeeder = -1;


    while (start_index>=0) {
	    indexOfFSU = searchIndexOfFSU(start_index);
	    if (indexOfFSU<0) return;

	    
	    indexOfFeeder = searchIndexOfFeeder();
	    if (indexOfFeeder<0) {
		/* if feeder does not exist, client returns error.*/
		freeDeviceList();
		return;
	    }

	    modelForFSUs[indexOfFSU]   = strdup(backendNames[indexOfFeeder]);

	    char *smodel = malloc(strlen(devices[indexOfFeeder]->model) + strlen("w/flatbed") + 1/*NULL*/);
	     if (smodel==NULL) return;

	    if (devices[indexOfFSU]->model) free(devices[indexOfFSU]->model);
	    devices[indexOfFSU]->model = smodel;
	    strcpy(devices[indexOfFSU]->model, devices[indexOfFeeder]->model);
	    strcat(devices[indexOfFSU]->model, "w/flatbed");
       	    

           start_index=indexOfFSU+1;
     }

   
}

      
void show_DeviceList()
{
   int idev=0;

    for (idev = 0;idev < MAX_DEVICES && devices[idev] != NULL;idev++) {
        fprintf(stderr, "[client]name is %s\r\n", devices[idev]->name);
        fprintf(stderr, "[client]vendor is %s\r\n", devices[idev]->vendor);
        fprintf(stderr, "[client]model is %s\r\n", devices[idev]->model);
        fprintf(stderr, "[client]type is %s\r\n", devices[idev]->type);
        fprintf(stderr, "[client]backendNames is %s\r\n", backendNames[idev]);
	 if (scannerTypes[idev]) {
		fprintf(stderr, "[client]flatbed\r\n");
	        fprintf(stderr, "[client]modelForFSUs is %s\r\n", modelForFSUs[idev]);
         } else {
		fprintf(stderr, "[client]feeder\r\n");
	}
    }

}


static SANE_Status doGetDeviceList(void)
{
    FILE *fp;
    char buf[4096];
    const char *p;


     /* initialize global value  */ 
    // vendor[0]=0;
    model[0]=0;
    type[0]=0;
    backendName[0]=0;
    scannerType=0;
    

    freeDeviceList();

    /* read config file */
    if ((fp = sanei_config_open(CFG_FILE_NAME)) == NULL) {
        return SANE_STATUS_ACCESS_DENIED;
    }
    while (sanei_config_read(buf,sizeof(buf),fp) != NULL) {



        p = sanei_config_skip_whitespace(buf);
        if (*p == '\0') continue; /* empty line */
        if (*p == '#') continue; /* comment line */
        if (strncmp(p,"option",6) == 0) {
            /* options */
            char *optname;
            char *optvalue;
        
            p = sanei_config_get_string(p+6,&optname);
            p = sanei_config_get_string(p,&optvalue);
            if (optname == NULL || optvalue == NULL
	          || optname[0] == 0 || optvalue[0] == 0) {
                /* no option name or no value */
		optname = NULL; /* dummy code for a bug of gcov 3.4.6 */
                continue;
            }


            if (strcmp(optname,"vendor") == 0) {

                snprintf(vendor,sizeof(vendor),"%s",optvalue);
            } else if (strcmp(optname,"model") == 0) {

                snprintf(model,sizeof(model),"%s",optvalue);
            } else if (strcmp(optname,"type") == 0) {

                snprintf(type,sizeof(type),"%s",optvalue);
            } else if (strcmp(optname,"backend") == 0) {

                snprintf(backendName,sizeof(backendName),"%s",optvalue);
            } else if (strcmp(optname,"scanner_type") == 0) {

			if (strcmp(optvalue,"flatbed_option")==0) {
				scannerType=1;
			} else {
				scannerType=0;
			}
	      }

			
            free(optvalue);
            free(optname);
        } else {
            /* device */

            sanei_usb_attach_matching_devices(p,canon_attach);

	     /* initialize global value  */ 
	     //vendor[0]=0;
            model[0]=0;
            type[0]=0;
            backendName[0]=0;
	     scannerType=0;


        }
    }
    fclose(fp);

    /* process for FlatbedScannerUnit */
    updateFSUDeviceList();

	/* show device list*/
	//show_DeviceList();

    return SANE_STATUS_GOOD;
}

SANE_Status sane_init(SANE_Int *version_code, SANE_Auth_Callback authorize)
{
    if (version_code) {
        *version_code = SANE_VERSION_CODE(V_MAJOR,V_MINOR,BUILD);
    }
    sanei_usb_init();
    return SANE_STATUS_GOOD;
}

static void freeRawOptions(CanonDevice *dev)
{
    if (dev->rawOptions.num_options > 0) {
        /* free descriptor array */
        sanei_w_set_dir(&(dev->wire),WIRE_FREE);
        sanei_w_option_descriptor_array(&(dev->wire),&(dev->rawOptions));
        dev->rawOptions.num_options = 0;
    }
}

static void freeOptions(CanonDevice *dev)
{
    /* free copy of raw Options
       Note: it's shallow copied. */
    if (dev->options.num_options > 0) {
        int i;

        for (i = 0;i < dev->options.num_options;i++) {
            free((void *)dev->options.desc[i]);
        }
        free((void *)dev->options.desc);
        dev->options.num_options = 0;
    }
}

static void doFreeOpenDevice(CanonDevice *dev)
{
    if (dev->fd >= 0) {
        freeRawOptions(dev);
        freeOptions(dev);
        sanei_w_exit(&(dev->wire));
        close(dev->fd);
        if (dev->dataFd >= 0) close(dev->dataFd);
    }
    dev->fd = -1;
    if (dev->backendPID >= 0) {
        /* prevent backend process from becoming a zombie */
        waitpid(dev->backendPID,NULL,0);
    }
    if (dev->comPID >= 0) {
        /* prevent com process from becoming a zombie */
        waitpid(dev->comPID,NULL,0);
    }
    dev->backendPID = -1;
    dev->comPID = -1;
}

static void freeOpenDevice(CanonDevice *dev)
{
    free(dev->name);
    dev->name = NULL;
    doFreeOpenDevice(dev);
}

static SANE_Status getOptions(CanonDevice *dev)
{
    int i;

    /* get all options from the backend */
    /* free old one */
    freeRawOptions(dev);
    /* get new one */
    sanei_w_call (&(dev->wire),SANE_NET_GET_OPTION_DESCRIPTORS,
      (WireCodecFunc)sanei_w_word,&(dev->backendHandle),
      (WireCodecFunc)sanei_w_option_descriptor_array,&(dev->rawOptions));
    if (dev->wire.status != 0 || BRANCH_TEST(1)) {
        doFreeOpenDevice(dev);
        return SANE_STATUS_IO_ERROR;
    }

    /* shallow copy them */
    if (dev->options.num_options == 0) {
        if ((dev->options.desc
              = (SANE_Option_Descriptor **)
                malloc(sizeof(SANE_Option_Descriptor *)
                  *dev->rawOptions.num_options)) == NULL
                  || BRANCH_TEST(2)) {
            return SANE_STATUS_NO_MEM;
        }
        for (i = 0;i < dev->rawOptions.num_options;i++) {
            if ((dev->options.desc[i] 
                 = (SANE_Option_Descriptor *)
                    malloc(sizeof(SANE_Option_Descriptor))) == NULL
                    || BRANCH_TEST(3)) {
                return SANE_STATUS_NO_MEM;
            }
        }
        dev->options.num_options = dev->rawOptions.num_options;
    }
    if (dev->options.num_options != dev->rawOptions.num_options
        || BRANCH_TEST(4)) {
        return SANE_STATUS_INVAL;
    }
    for (i = 0;i < dev->options.num_options;i++) {
        memcpy(dev->options.desc[i],dev->rawOptions.desc[i],
          sizeof(SANE_Option_Descriptor));
    }
    return SANE_STATUS_GOOD;
}

void sane_exit(void)
{
    int i;

    /* free open devices */
    for (i = 0;i < MAX_DEVICES;i++) {
        if (openDevices[i].name != NULL) {
            sane_close((SANE_Handle)i);
        }
    }
    freeDeviceList();
}

SANE_Status sane_get_devices(const SANE_Device *** device_list,
  SANE_Bool local_only)
{
    SANE_Status status;

    status = doGetDeviceList();
    if (status == SANE_STATUS_GOOD) {
        *device_list = (const SANE_Device **)devices;
    }
    return status;
}

SANE_Status sane_open(SANE_String_Const devicename, SANE_Handle * handle)
{
    SANE_Status status;
    int i, idev, icdev;
    int cominfds[2]; /* pipe for input from communication module */
    int comoutfds[2]; /* pipe for output to communication module */
    int bkfds[2]; /* socket pair to communicate with backend module.
                    index 0 : client side, index 1: backend side */
    pid_t pid;
    SANE_Init_Req initReq;
    SANE_Init_Reply initReply;
    SANE_Open_Reply openReply;

    if (devices[0] == NULL) {
        status = doGetDeviceList();
        if (status != SANE_STATUS_GOOD) {
            return status;
        }
    }

    /* check device name */
    for (idev = 0;idev < MAX_DEVICES && devices[idev] != NULL;idev++) {
        if (strcmp(devices[idev]->name,devicename) == 0) {
            break;
        }
    }
    if (idev >= MAX_DEVICES || devices[idev] == NULL) {
        /* specified device is not found */
        return SANE_STATUS_INVAL;
    }

    /* setup canon device structure */
    /* check if already open */
    icdev = -1;
    for (i = 0;i < MAX_DEVICES;i++) {
        if (openDevices[i].name == NULL) {
            icdev = i; 
        } else if (strcmp(openDevices[i].name,devicename) == 0) {
            /* already open */
            return SANE_STATUS_DEVICE_BUSY;
        }
    }
    if (icdev < 0 || BRANCH_TEST(5)) {
        /* too many open devices */
        return SANE_STATUS_INVAL;
    }
    if ((openDevices[icdev].name = strdup(devicename)) == NULL
        || BRANCH_TEST(6)) {
        return SANE_STATUS_NO_MEM;
    }
    openDevices[icdev].fd = -1;
    openDevices[icdev].dataFd = -1;

    /* initialize fds of pipes for error handling */
    cominfds[0] = cominfds[1] = -1;
    comoutfds[0] = comoutfds[1] = -1;
    bkfds[0] = bkfds[1] = -1;

    /* spawn communication module */
    /* create pipe */
    if (pipe(cominfds) < 0 || BRANCH_TEST(7)) {
        status = SANE_STATUS_IO_ERROR;
        goto err0;
    }
    if (pipe(comoutfds) < 0 || BRANCH_TEST(8)) {
        status = SANE_STATUS_IO_ERROR;
        goto err0;
    }
    
    if ((pid = fork()) == 0) {
        /* child process */
        /* connect the pipe to stdio */
        dup2(comoutfds[0],0);
        close(comoutfds[0]);
        close(comoutfds[1]);
        dup2(cominfds[1],1);
        close(cominfds[0]);
        close(cominfds[1]);
        /* now exec communication module */
        if (!BRANCH_TEST(9)) {
            execl(DRBINPATH "/" COMM_MODULE,COMM_MODULE,devicename,
              (const char *)NULL);
        }
        /* exec fail */
        exit(2);
    }
    if (pid < 0 || BRANCH_TEST(10)) {
        /* fork fail */
        status = SANE_STATUS_IO_ERROR;
        goto err0;
    }
    openDevices[icdev].comPID = pid;
    /* close communication module side fds */
    close(comoutfds[0]);
    comoutfds[0] = -1;
    close(cominfds[1]);
    cominfds[1] = -1;

    /* spawn backend module */
    /* create socket pair
       Because of sanei_wire specification,
       we use socket pair instead of pipe. */
    if (socketpair(AF_UNIX, SOCK_STREAM, PF_UNIX, bkfds) < 0
         || BRANCH_TEST(11)) {
        status = SANE_STATUS_IO_ERROR;
        goto err0;
    }
    if ((pid = fork()) == 0) {
        char *modName = BACKEND_MODULE;
        char rfdno[10], wfdno[10];
        char buf[PATH_MAX];
        /* child process */

        /* connect the pipe to stdio */
        dup2(bkfds[1],0);
        dup2(bkfds[1],1);
        /* close client side */
        close(bkfds[0]);
        close(bkfds[1]);

        if (backendNames[idev] != NULL) {
            /* backend module name is specified explicitly */
            modName = backendNames[idev];
        }
        /* setup argument for fd numbers of pipe to communication modules */
        snprintf(rfdno,sizeof(rfdno),"%d",cominfds[0]);
        snprintf(wfdno,sizeof(wfdno),"%d",comoutfds[1]);

        snprintf(buf,sizeof(buf),DRBINPATH "/%s",modName);

	/* now exec backend module */
	 if (scannerTypes[idev]==1) {

		/* flatbed option*/
		int idev_feeder=0;
		
		/* search information of feeder from devices[]*/
		idev_feeder = searchIndexOfFeeder();

		/* now exec backend module */
		execl(buf,modName,devices[idev]->model,
		  "-r",rfdno,"-w",wfdno, 
		  "-b",backendNames[idev_feeder],"-m",devices[idev_feeder]->model,"-d",devices[idev_feeder]->name,(const char *)NULL);

	 } else {

		/* feeder only*/
		execl(buf,modName,devices[idev]->model,
		  "-r",rfdno,"-w",wfdno, (const char *)NULL);
	}
        /* exec fail */
        exit(2);
    }
    if (pid < 0 || BRANCH_TEST(12)) {
        /* fork fail */
        status = SANE_STATUS_IO_ERROR;
        goto err0;
    }
    openDevices[icdev].backendPID = pid;
    /* communication pipe fds is not used any more, close them */
    close(comoutfds[1]);
    comoutfds[1] = -1;
    close(cominfds[0]);
    cominfds[0] = -1;
    /* close backend module side fds */
    close(bkfds[1]);
    bkfds[1] = -1;
    /**/
    openDevices[icdev].fd = bkfds[0];
    bkfds[0] = -1;
    /* init wire */
    sanei_w_init(&(openDevices[icdev].wire),sanei_codec_bin_init);
    openDevices[icdev].wire.io.fd = openDevices[icdev].fd;
    openDevices[icdev].wire.io.write = write;
    openDevices[icdev].wire.io.read = read;

    /* now communicatio and backend modules are spawned.
       call sane_init and sane_open of the backend module */
    /* call sane_init */
    initReq.version_code = SANE_VERSION_CODE(V_MAJOR,V_MINOR,BUILD);
    initReq.username = getlogin();
    sanei_w_call(&(openDevices[icdev].wire),SANE_NET_INIT,
      (WireCodecFunc)sanei_w_init_req,&initReq,
      (WireCodecFunc)sanei_w_init_reply,&initReply);
    if (openDevices[icdev].wire.status != 0) {
        /* sane_init fail */
        status = SANE_STATUS_IO_ERROR;
        goto err0;
    }
    status = initReply.status;
    sanei_w_free(&(openDevices[icdev].wire),
       (WireCodecFunc)sanei_w_init_reply,&initReply);
    if (BRANCH_TEST(13)) {
        status = SANE_STATUS_IO_ERROR;
    }
    if (status != SANE_STATUS_GOOD) {
        goto err0;
    }

    /* call sane_open */
    sanei_w_call(&(openDevices[icdev].wire), SANE_NET_OPEN,
      (WireCodecFunc)sanei_w_string,&devicename,
      (WireCodecFunc)sanei_w_open_reply,&openReply);
    if (openDevices[icdev].wire.status != 0 || BRANCH_TEST(15)) {
        /* sane_open fail */
        status = SANE_STATUS_IO_ERROR;
        goto err0;
    }
    status = openReply.status;
    if (status != SANE_STATUS_GOOD) {
        goto err0;
    }
    openDevices[icdev].backendHandle = (SANE_Handle)openReply.handle;
    sanei_w_free(&(openDevices[icdev].wire),
      (WireCodecFunc)sanei_w_open_reply,&openReply);
    *handle = (SANE_Handle)icdev;

    return SANE_STATUS_GOOD;

err0:
    /* error handling */
    /* cleanup fds of pipes */
    if (cominfds[0] >= 0) close(cominfds[0]);
    if (cominfds[1] >= 0) close(cominfds[1]);
    if (comoutfds[0] >= 0) close(comoutfds[0]);
    if (comoutfds[1] >= 0) close(comoutfds[1]);
    if (bkfds[0] >= 0) close(bkfds[0]);
    if (bkfds[1] >= 0) close(bkfds[1]);

    freeOpenDevice(&openDevices[icdev]);
    return status;
}

void sane_close(SANE_Handle handle)
{
    CanonDevice *cdev;
    SANE_Word ack;

    if (handle2Dev(handle,&cdev) == SANE_STATUS_INVAL) return;
    if (cdev->fd >= 0) {
        /* call backend side sane_close */
        sanei_w_call(&(cdev->wire),SANE_NET_CLOSE,
          (WireCodecFunc)sanei_w_word,&(cdev->backendHandle),
          (WireCodecFunc)sanei_w_word,&ack);
        /* call backend size sane_exit */
        sanei_w_call(&(cdev->wire),SANE_NET_EXIT,
          (WireCodecFunc)sanei_w_void,NULL,(WireCodecFunc)sanei_w_void,NULL);
    }

    freeOpenDevice(cdev);
}

const SANE_Option_Descriptor *
  sane_get_option_descriptor(SANE_Handle handle, SANE_Int option)
{
    CanonDevice *cdev;
    SANE_Status status;

    if (handle2Dev(handle,&cdev) != SANE_STATUS_GOOD) return NULL;
    if (cdev->options.num_options <= 0) {
        if ((status = getOptions(cdev)) != SANE_STATUS_GOOD) {
            return NULL;
        }
    }
    if (option >= 0 && option < cdev->options.num_options) {
        return cdev->options.desc[option];
    }
    return NULL;
}

SANE_Status sane_control_option(SANE_Handle handle, SANE_Int option,
  SANE_Action action, void *value, SANE_Int *info)
{
    CanonDevice *cdev;
    SANE_Status status;
    SANE_Control_Option_Req req;
    SANE_Control_Option_Reply reply;
    SANE_Int tinfo = 0;

    if ((status = handle2Dev(handle,&cdev)) != SANE_STATUS_GOOD) return status;
    if (cdev->options.num_options <= 0) {
        if ((status = getOptions(cdev)) != SANE_STATUS_GOOD
           || BRANCH_TEST(16)) {
            return status;
        }
    }
    if (option < 0 || option >= cdev->options.num_options) {
        return SANE_STATUS_UNSUPPORTED;
    }
    if (action == SANE_ACTION_SET_VALUE) {
        if ((status = sanei_constrain_value(cdev->options.desc[option],
           value, &tinfo)) != SANE_STATUS_GOOD || BRANCH_TEST(17)) {
            return status;
        }
    }

    /* now call backend */
    req.handle = (SANE_Word)cdev->backendHandle;
    req.option = option;
    req.action = action;
    req.value_type = cdev->options.desc[option]->type;
    req.value = value;
    switch (cdev->options.desc[option]->type) {
    case SANE_TYPE_BUTTON:
    case SANE_TYPE_GROUP:
        req.value_size = 0;
        break;
    case SANE_TYPE_STRING:
        if (action == SANE_ACTION_SET_VALUE) {
            req.value_size = strlen((char *)value)+1;
        } else {
            req.value_size = cdev->options.desc[option]->size;
        }
        break;
    default:
        req.value_size = cdev->options.desc[option]->size;
        break;
    }
    if (action == SANE_ACTION_SET_AUTO) req.value_size = 0;
    sanei_w_call(&(cdev->wire),SANE_NET_CONTROL_OPTION,
      (WireCodecFunc)sanei_w_control_option_req,&req,
      (WireCodecFunc)sanei_w_control_option_reply,&reply);
    if (cdev->wire.status != 0 || BRANCH_TEST(18)) {
        doFreeOpenDevice(cdev);
        return SANE_STATUS_IO_ERROR;
    }
    if (reply.status != SANE_STATUS_GOOD) {
        return reply.status;
    }
    if (reply.value_size > 0) {
        /* copy value */
        if (reply.value_size > req.value_size || BRANCH_TEST(26)) {
            status = SANE_STATUS_IO_ERROR;
            goto err;
        }
        memcpy(value,reply.value,reply.value_size);
    }
    tinfo |= reply.info;
    if (tinfo & SANE_INFO_RELOAD_OPTIONS) {
        if (info == NULL) {
            /* reget options because a frontend doesn't care of it */
            if ((status = getOptions(cdev)) != SANE_STATUS_GOOD
                || BRANCH_TEST(19)) {
                goto err;
            }
        } else {
            freeOptions(cdev);
        }
    }
    if (info != NULL) {
        *info = tinfo;
    }
    status = SANE_STATUS_GOOD;

err:
    sanei_w_free(&(cdev->wire),(WireCodecFunc)sanei_w_control_option_reply,
       &reply);
    return status;
}

SANE_Status sane_get_parameters(SANE_Handle handle, SANE_Parameters * params)
{
    CanonDevice *cdev;
    SANE_Get_Parameters_Reply reply;
    SANE_Status  status;

    if ((status = handle2Dev(handle,&cdev)) != SANE_STATUS_GOOD) return status;
    if (params == NULL) {
        return SANE_STATUS_INVAL;
    }
    sanei_w_call(&(cdev->wire), SANE_NET_GET_PARAMETERS,
      (WireCodecFunc)sanei_w_word,&(cdev->backendHandle),
      (WireCodecFunc)sanei_w_get_parameters_reply,&reply);
    if (cdev->wire.status != 0 || BRANCH_TEST(20)) {
        doFreeOpenDevice(cdev);
        return SANE_STATUS_IO_ERROR;
    }
    *params = reply.params;
    status = reply.status;

    sanei_w_free(&(cdev->wire),(WireCodecFunc)sanei_w_get_parameters_reply,
      &reply);

    return status;
}

SANE_Status sane_start(SANE_Handle handle)
{
    CanonDevice *cdev;
    SANE_Start_Reply reply;
    SANE_Status status;

    if ((status = handle2Dev(handle,&cdev)) != SANE_STATUS_GOOD) return status;
    sanei_w_call (&(cdev->wire),SANE_NET_START,(WireCodecFunc)sanei_w_word,
      &(cdev->backendHandle),(WireCodecFunc)sanei_w_start_reply,&reply);
    if (cdev->wire.status != 0 || BRANCH_TEST(21)) {
        doFreeOpenDevice(cdev);
        return SANE_STATUS_IO_ERROR;
    }
    status = reply.status;
    if (status == SANE_STATUS_GOOD) {
        /* In this driver, 
         a server side file descriptor No. of a pipe for image data pipe
         in reply.port */
        char buf[PATH_MAX];

        /* open the client side of pipe using proc filesystem */
        snprintf(buf,sizeof(buf),"/proc/%d/fd/%d",cdev->backendPID,reply.port);
        if (BRANCH_TEST(27) || (cdev->dataFd = open(buf,O_RDONLY)) < 0) {
            status = SANE_STATUS_IO_ERROR;
        }
        cdev->dataSize = 0;
    }
    sanei_w_free(&(cdev->wire),(WireCodecFunc)sanei_w_start_reply,&reply);
    return status;
}

static int doRead(int fd, unsigned char *buf, unsigned int size)
{
    int r;
    unsigned char *p;

    p = buf;
    while (size > 0) {
        if (BRANCH_TEST(22) || BRANCH_TEST(23)) {
            r = -1;
        } else {
            r = read(fd,p,size);
        }
        if (r <= 0) {
            if (((r < 0) && (errno == EAGAIN || errno == EINTR))
                || BRANCH_TEST(23)) {
                CLEAR_BRANCH();
                continue;
            }
            return -1;
        }
        p += r;
        size -= r;
    }
    return 0;
}

SANE_Status sane_read(SANE_Handle handle, SANE_Byte * data,
  SANE_Int max_length, SANE_Int * length)
{
    SANE_Status status;
    CanonDevice *cdev;
    unsigned int dataLen;
    unsigned char lenBuf[4];
    int i;

    if ((status = handle2Dev(handle,&cdev)) != SANE_STATUS_GOOD) return status;

    *length = 0;

    if (cdev->dataFd < 0) {
        return SANE_STATUS_CANCELLED;
    }
    if (cdev->dataSize == 0) {
        /* read data packet length */
        if (doRead(cdev->dataFd,lenBuf,4) < 0 || BRANCH_TEST(24)) {
            return SANE_STATUS_IO_ERROR;
        }
        dataLen = 0;
        for (i = 0;i < 4;i++) {
            dataLen = (dataLen << 8) | (lenBuf[i] & 0xff);
        }

        if (dataLen == 0xffffffff) {
            /* EOF or error */
            unsigned char c;

            /* read status
              NOTE: Though this is undocumented in SANE Protocol,
              the net backend does.
            */
            status = SANE_STATUS_IO_ERROR;
            if (doRead(cdev->dataFd,&c,1) >= 0) {
                status = (SANE_Status)c;
            }

            close(cdev->dataFd);
            cdev->dataFd = -1;
            return status;
        }
        cdev->dataSize = dataLen;
    }

    dataLen = cdev->dataSize < max_length ? cdev->dataSize : max_length;
    if (doRead(cdev->dataFd,data,dataLen) < 0 || BRANCH_TEST(25)) {
        return SANE_STATUS_IO_ERROR;
    }
    cdev->dataSize -= dataLen;
    *length = dataLen;
    return SANE_STATUS_GOOD;
}

void sane_cancel(SANE_Handle handle)
{
    CanonDevice *cdev;
    SANE_Word ack;

    if (handle2Dev(handle,&cdev) != SANE_STATUS_GOOD) return;
    sanei_w_call(&(cdev->wire),SANE_NET_CANCEL,(WireCodecFunc)sanei_w_word,
      &(cdev->backendHandle),(WireCodecFunc)sanei_w_word, &ack);
    if (cdev->dataFd >= 0) close(cdev->dataFd);
    cdev->dataFd = -1;
    cdev->dataSize = 0;
}

SANE_Status sane_set_io_mode(SANE_Handle handle, SANE_Bool non_blocking)
{
    if (non_blocking != SANE_FALSE) {
        return SANE_STATUS_UNSUPPORTED;
    }
    return SANE_STATUS_GOOD;
}

SANE_Status sane_get_select_fd(SANE_Handle handle, SANE_Int * fd)
{
    CanonDevice *cdev;
    SANE_Status status;

    if ((status = handle2Dev(handle,&cdev)) != SANE_STATUS_GOOD) return status;
    if (cdev->dataFd < 0) {
        return SANE_STATUS_INVAL;
    }
    *fd = cdev->dataFd;
    return SANE_STATUS_GOOD;
}

SANE_String_Const sane_strstatus(SANE_Status status)
{
    switch (status) {
    case SANE_STATUS_GOOD:
        return "Success";
        break;
    case SANE_STATUS_UNSUPPORTED:
        return "Not supported";
        break;
    case SANE_STATUS_CANCELLED:
        return "Cancelled";
        break;
    case SANE_STATUS_DEVICE_BUSY:
        return "Busy";
        break;
    case SANE_STATUS_INVAL:
        return "Invalid data";
        break;
    case SANE_STATUS_EOF:
        return "End of file";
        break;
    case SANE_STATUS_JAMMED:
        return "Jammed";
        break;
    case SANE_STATUS_NO_DOCS:
        return "No documents";
        break;
    case SANE_STATUS_COVER_OPEN:
        return "Cover open";
        break;
    case SANE_STATUS_IO_ERROR:
        return "I/O error";
        break;
    case SANE_STATUS_NO_MEM:
        return "Out of memory";
        break;
    case SANE_STATUS_ACCESS_DENIED:
        return "Access denied";
        break;
    default:
        return "Unknown error";
    }
}
