#!/bin/sh
INSTALLDIR=/opt/Canon
DOCDIR=/usr/share/doc/cndrvsane-drm260

mkdir -p $INSTALLDIR/etc/sane.d/canondr
mkdir -p $INSTALLDIR/lib/canondr
mkdir -p $INSTALLDIR/lib/canondr/drm260
mkdir -p $INSTALLDIR/lib/sane

cd bin
if [ -e ./install.sh ]
then
	chmod 755 ./install.sh
	./install.sh $INSTALLDIR 
else
	echo "bin/install.sh is not exist!"
	exit 1
fi
cd ..

cd configs
if [ -e ./install.sh ]
then
	chmod 755 ./install.sh
	./install.sh $INSTALLDIR
else
	echo "configs/install.sh is not exist!"
	exit 1
fi
cd ..

cd src
if [ -e ./install.sh ]
then
	chmod 755 ./install.sh
	./install.sh $INSTALLDIR
else
	echo "src/install.sh is not exist!"
	exit 1
fi
cd ..

rm -rf $DOCDIR*
mkdir -p $DOCDIR

cp -f ./COPYING $DOCDIR

cp -f ./README $DOCDIR

cp -f ./LICENSE-drm260-1.00E.txt $DOCDIR

cp -f ./LICENSE-drm260-1.00J.txt $DOCDIR

cp -f ./README-drm260-1.00.txt $DOCDIR



